# H5 试玩广告包（核玩工具导出）

本 ZIP 含一个或多个广告渠道子目录。每个子目录是**自包含** HTML5 试玩：打开 `index.html` 即可离线游玩（无编辑器面板），底部 CTA 跳转应用商店 / 落地页。

## 多尺寸自适应（Responsive）

试玩壳采用 **contain / letterbox** 策略：游戏舞台保持设计画幅比例（默认 9:16 / `canvasW×canvasH`），在设备视口内等比缩放并居中；上下或左右留出与背景色一致的黑边。支持手机（SE→Pro Max、Pixel、Galaxy）、平板（iPad Mini/Air/Pro、Surface）、折叠屏（Z Fold 外屏、Duo）及横屏平板，**不是**固定死 720×1280 CSS 盒子。

- 视口：`width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover`
- 全屏：`100vw` / `100dvh` + `safe-area-inset-*`
- CTA：底部 sticky，预留 `safe-area-inset-bottom`
- `h5Orientation`：`1` 竖屏优先，`2` 横屏创意，`0` 双端（横屏设备上仍 contain 竖屏内容，可玩不裁切）
- 运行时：`window.__h5FitStage()` / `window.__h5StageLayout`；`resize` / `orientationchange` / `visualViewport` 时重算

## 目录

| 文件夹 | 渠道 | CTA |
|--------|------|-----|
| `tiktok/` | TikTok / Pangle 试玩 | `window.openAppStore()`，否则打开商店 URL；含 `config.json`（`playable_orientation`） |
| `google/` | Google Ads Playable | `ExitApi.exit()`（含 stub）；相对路径；竖屏 meta |
| `mintegral/` | Mintegral | `window.install()` → `window.gameEnd()` → 商店 URL |
| `generic/` | 通用离线包 | 点击打开商店 URL；附 `README.txt` |

## 限制

- 目标体积 ≤ 5MB（超限请压缩贴图 / 关闭多余资源）。Google：≤512 文件。
- 试玩包**不含**设置面板、AE/3D 导出等编辑器功能；设置已烘焙进页面。
- three.js 工具体积较大时可能接近上限，属已知限制。

## 本地预览

用本地静态服务器打开对应渠道的 `index.html`（部分渠道 SDK 在 `file://` 下行为不同）。用 Chrome DevTools Device Toolbar 切换 SE / 14 Pro Max / iPad / Z Fold 等验证 letterbox 与 CTA。
