Generic offline H5 playable
Open index.html in a browser (preferably via a local static server).
CTA opens: https://example.com/app
No ad-network SDK required.
